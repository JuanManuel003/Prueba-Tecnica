--CREAR LA TABLA CON LA QUE VAMOS A TRABAJAR
CREATE TABLE USUARIOS (
    ID_USUARIO NUMBER PRIMARY KEY,
    LOGIN VARCHAR2(50) NOT NULL UNIQUE,
    CONTRASENA VARCHAR2(50) NOT NULL,
    ESTADO NUMBER(1) DEFAULT 0 -- 1 para Activo, 0 para Inactivo
);

--CREAR EL PROCEDIMIENTO QUE NOS PIDE ESTE PUNTO 
CREATE OR REPLACE PROCEDURE manejar_usuario (
    p_accion     IN VARCHAR2, -- 'INSERTAR', 'ACTUALIZAR', 'CAMBIAR_ESTADO'
    p_id_usuario IN NUMBER DEFAULT NULL, -- solo para actualizar y cambiar estado
    p_login      IN VARCHAR2 DEFAULT NULL, -- solo para insertar y actualizar
    p_contrasena IN VARCHAR2 DEFAULT NULL, -- solo para insertar y actualizar
    p_estado     IN CHAR DEFAULT NULL -- Estado del usuario solo para cambiar estado
) IS
BEGIN
    IF p_accion = 'INSERTAR' THEN
        INSERT INTO usuarios (
            login,
            contrasena,
            estado
        ) VALUES (
            p_login,
            p_contrasena,
            'A'
        ); -- Por defecto, se inserta como Activo

    ELSIF p_accion = 'ACTUALIZAR' THEN
        UPDATE usuarios
        SET
            login = p_login,
            contrasena = p_contrasena
        WHERE
            id_usuario = p_id_usuario;

    ELSIF p_accion = 'CAMBIAR_ESTADO' THEN
        UPDATE usuarios
        SET
            estado = p_estado
        WHERE
            id_usuario = p_id_usuario;

    ELSE
        raise_application_error(-20001, 'Acci�n no v�lida. Use INSERTAR, ACTUALIZAR o CAMBIAR_ESTADO.');
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        raise_application_error(-20002, 'Error al procesar la acci�n: ' || sqlerrm);
END;
