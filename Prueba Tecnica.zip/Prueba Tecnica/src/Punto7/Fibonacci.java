package Punto7;

import java.util.ArrayList;

import javax.swing.JOptionPane;

public class Fibonacci {

	public static void main(String[] args) {

		int opcionRespuesta;
		int numero=0;

		do{
		opcionRespuesta = Integer.parseInt(JOptionPane.showInputDialog("Menu \n\n"
												+ "1. ver los numeros hasta una posicion dada \n"
												+ "2. ver el numero de la serie fibo en una posicion especifica \n"
												+ "3. Saber si un numero hace parte o no de la serie fibonacci \n"
												+ "4. salir"));
			switch (opcionRespuesta) {
			case 1:
				numero = Integer
						.parseInt(JOptionPane.showInputDialog("hasta que posici�n desea ver la serie fibonacci"));
				fibonacciNumeros(numero);
				break;
			case 2:
				numero = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la posici�n del numero que desea ver"));
				Seriefibonacci(numero);
				break;
			case 3:
				numero = Integer
						.parseInt(JOptionPane.showInputDialog("Ver si un numero pertenece a la serie fibonacci"));
				esNumeroFibonacci(numero);
				break;
			case 4:

				break;
			default:
				break;
			}

		} while (opcionRespuesta != 4);
	}

	// METODO PARA ENCONTRAR LOS N PRIMEROS NUMEROS DE LA SERIE
	public static void fibonacciNumeros(int numero) {
		// VARIABLES A USAR
		int resultado = 0;
		int numeroActual = 1;
		int numeroAnterior = 0;
		ArrayList<Integer> fibonacci = new ArrayList<Integer>();
		fibonacci.add(numeroAnterior);
		fibonacci.add(numeroActual);

		// SUCESI�N FIBONACCI
		for (int i = 2; i < numero; i++) {
			resultado = numeroAnterior + numeroActual;
			numeroAnterior = numeroActual;
			numeroActual = resultado;
			fibonacci.add(resultado);
		}

		System.out.println("los numeros hasta la posici�n " + numero + " son: " + fibonacci.toString());
	}

	// METODO PARA HACER EL RECORRIDO FIBONACCI HASTA UN NUMERO Y RETORNE ESE NUMERO
	public static void Seriefibonacci(int numero) {
		// VARIABLES A USAR
		int resultado = 0;
		int numeroActual = 1;
		int numeroAnterior = 0;

		// SUCESI�N FIBONACCI
		for (int i = 2; i < numero; i++) {
			resultado = numeroAnterior + numeroActual;
			numeroAnterior = numeroActual;
			numeroActual = resultado;
		}

		System.out.println("En la serie fibonacci, el numero en la posici�n " + numero + " es el: " + resultado);
	}

	//METODO PARA SABER SI UN NUMERO ESTA EN LA SUCESI�N FIBONACCI
	public static void esNumeroFibonacci(int numero) {
        if (numero == 0 || numero == 1) {
        	System.out.println("El numero "+numero+" hace parte de la sucesi�n fibonacci");;
        }

        int a = 0;
        int b = 1;

        while (b < numero) {
            int temporal = a + b;
            a = b;
            b = temporal;
        }

        if(b == numero){
        	System.out.println("El numero "+numero+" hace parte de la sucesi�n fibonacci");;
        }else{
        	System.out.println("El numero "+numero+" NO hace parte de la sucesi�n fibonacci");;
        }

    }

}
