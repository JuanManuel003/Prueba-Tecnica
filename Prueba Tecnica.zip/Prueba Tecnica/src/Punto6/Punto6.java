package Punto6;

import java.util.ArrayList;

import javax.swing.JOptionPane;

import com.sun.javafx.scene.control.skin.TooltipSkin;

public class Punto6 {

	public static void main(String[] args) {

		// DECLARACION DE VARIABLES
		String nombre;
		String apellido;
		String correo;
		String contrasenia;
		String confContrasenia;

		// INICIALIZACI�N DE LAS VARIABLES

		nombre = JOptionPane.showInputDialog("Ingrese el nombre del usuario");
		apellido = JOptionPane.showInputDialog("Ingrese el apellido del usuario");
		correo = JOptionPane.showInputDialog("Ingrese el correo del usuario");
		contrasenia = JOptionPane.showInputDialog("Ingrese la contrase�a del usuario");
		confContrasenia = JOptionPane.showInputDialog("Confirme la contrase�a anteriormente ingresada");

		// VALIDACIONES DE LA CONTRASE�A
		boolean valTamanio = TamanioContrasenia(contrasenia);
		boolean valMayuscula = ContieneMayuscula(contrasenia);
		boolean valNumero = ContieneNumero(contrasenia);
		boolean valCaracEspecial = ContieneCaracEspecial(contrasenia);
		boolean valDifNombreDifApellido = DifNombreDifApellido(nombre, apellido, contrasenia);
		boolean contraseniaConfirmada = ConfirmarContrasenia(contrasenia, confContrasenia);

		// VALIDACIONES DEL CORREO
		boolean contArroba = valArroba(correo);
		boolean contPunto = valPunto(correo);

		// VALIDAR TODA LA INFORMACI�N JUNTA
		if (valTamanio == true && valMayuscula == true && valNumero == true && valCaracEspecial == true
				&& valDifNombreDifApellido == true && contraseniaConfirmada == true) {
			System.out.println("Contrase�a correcta");
			if (contArroba == true && contPunto == true) {
				System.out.println("Correo correcto");
				JOptionPane.showMessageDialog(null, "��Los datos cumplen con todos los requisitos!!");
			}
		}
		System.out.println("\nTermin� el programa");
	}

	// METODOS DE VALIDACI�N DE LA CONTRASE�A
	// ------------------------------------------------------------------------------------------------------------------------
	// VALIDAR QUE LA CONTRASE�A TENGA MAS DE 12 CARACTERES
	public static boolean TamanioContrasenia(String contrasenia) {
		char[] caracteres = contrasenia.toCharArray();
		if (caracteres.length < 12) {
			return false;
		}

		return true;
	}

	// VALIDAR SI LA CONTRASENIA CONTIENE MAYUSCULAS
	public static boolean ContieneMayuscula(String contrasenia) {
		for (int i = 0; i < contrasenia.length(); i++) {
			if (Character.isUpperCase(contrasenia.charAt(i))) {
				return true;
			}
		}
		return false;
	}

	// VALIDAR SI EN LA CONTRASE�A HAY UN NUMERO
	public static boolean ContieneNumero(String contrasenia) {
		for (int i = 0; i < contrasenia.length(); i++) {
			if (Character.isDigit(contrasenia.charAt(i))) {
				return true;
			}
		}
		return false;
	}

	// VALIDAR SI EN LA CONTRASE�A HAY ALGUN CARACTER ESPECIAL
	public static boolean ContieneCaracEspecial(String contrasenia) {
		for (int i = 0; i < contrasenia.length(); i++) {
			if (!Character.isLetterOrDigit(contrasenia.charAt(i))) {
				return true;
			}
		}
		return false;
	}

	// VALIDAR QUE LA CONTRASE�A SEA DIFERENTE AL NOMBRE Y AL APELLIDO DEL
	// USUARIO
	public static boolean DifNombreDifApellido(String nombre, String apellido, String contrasenia) {
		if (contrasenia.equals(nombre) || contrasenia.equals(apellido)) {
			return false;// ES DIFERENTE AL NOMBRE Y AL APELLIDO
		}
		return true;
	}

	// CONFIRMAR QUE LA CONFIRMACI�N DE LA CONTRASE�A SEA CORRECTA
	public static boolean ConfirmarContrasenia(String contrasenia, String valContrasenia) {
		if (valContrasenia.equals(contrasenia)) {
			return true;// LAS CONTRASE�AS SON IGUALES
		}
		return false;
	}

	// METODOS DE VALIDACI�N DEL CORREO ELECTRONICO
	// ------------------------------------------------------------------------------------------------------------------------

	// VALIDAR QUE EL CORREO CONTENGA EL CARACTER '@'
	public static boolean valArroba(String correo) {
		char[] caracteres = correo.toCharArray();
		for (int i = 0; i < caracteres.length; i++) {
			String item = String.valueOf(caracteres[i]);
			if (item.equals("@")) {
				return true;
			}
		}
		return false;
	}

	// VALIDAR QUE EL CORREO CONTENGA UN PUNTO '.'x
	public static boolean valPunto(String correo) {
		char[] caracteres = correo.toCharArray();
		for (int i = 0; i < caracteres.length; i++) {
			String item = String.valueOf(caracteres[i]);
			if (item.equals(".")) {
				return true;
			}
		}
		return false;
	}

	// VALIDAR QUE EL CORREO CONTENGA UNA DIRECCION CORRECTA 'COM' 'CO' 'ES'
	public static boolean valDireccion(String correo) {
		char[] caracteres = correo.toCharArray();
		ArrayList<Integer> posicionPuntos = new ArrayList<Integer>();
		for (int i = 0; i < caracteres.length; i++) {
			String item = String.valueOf(caracteres[i]);
			if (item.equals(".")) {
				posicionPuntos.add(i);// PARA GUARDAR EL VALOR DE LA POSICI�N
			}
		}

		// PARA COMENZAR DESDE LA POSICI�N DEL ULTIMO PUNTO
		for (int j = posicionPuntos.size(); j < caracteres.length; j++) {
			/*
			 * if(){
			 *
			 * }
			 */
		}
		return false;
	}

}
