--CREACI�N DE LA TABLA PACIENTES 
CREATE TABLE pacientes (
    id_paciente             NUMBER PRIMARY KEY,
    identificacion          NUMBER,
    nombre1                 VARCHAR2(50),
    nombre2                 VARCHAR2(50),
    apellido1               VARCHAR2(50),
    apellido2               VARCHAR2(50),
    fecha_nacimiento        DATE,
    fecha_creacion          DATE,
    estado                  NUMBER,-- 0 SI SU ESTADO ES INACTIVO, 1 SI ES ACTIVO 
    id_tipos_identificacion NUMBER,
    CONSTRAINT fk_tipos_identificacion FOREIGN KEY ( id_tipos_identificacion )
        REFERENCES tipos_identificacion ( id_identificacion )
);

--CREACI�N DE LA TABLA TIPOS_IDENTIFICACI�N
CREATE TABLE tipos_identificacion (
    id_identificacion NUMBER PRIMARY KEY,
    nombre            VARCHAR2(50),
    abreviatura       VARCHAR2(50),
    estado            NUMBER -- 0 SI SU ESTADO ES INACTIVO, 1 SI ES ACTIVO
);

--FUNCI�N 
CREATE OR REPLACE FUNCTION cant_pacientes_fechas (
    fecha_inicio DATE,
    fecha_fin    DATE
) RETURN NUMBER IS
    v_cantidad_pacientes NUMBER := 0;
BEGIN
    IF
        fecha_inicio IS NOT NULL
        AND fecha_fin IS NOT NULL
    THEN
        SELECT
            COUNT(p.id_paciente)
        INTO v_cantidad_pacientes
        FROM
            pacientes p
        WHERE
                p.estado = 1
            AND p.fecha_creacion BETWEEN fecha_inicio AND fecha_fin;

    ELSIF
        fecha_inicio IS NOT NULL
        AND fecha_fin IS NULL
    THEN
        SELECT
            COUNT(p.id_paciente)
        INTO v_cantidad_pacientes
        FROM
            pacientes p
        WHERE
                p.estado = 1
            AND p.fecha_creacion > fecha_inicio;

    ELSIF
        fecha_inicio IS NULL
        AND fecha_fin IS NULL
    THEN
        SELECT
            COUNT(p.id_paciente)
        INTO v_cantidad_pacientes
        FROM
            pacientes p
        WHERE
            p.estado = 1;

    END IF;

    RETURN v_cantidad_pacientes;
END;