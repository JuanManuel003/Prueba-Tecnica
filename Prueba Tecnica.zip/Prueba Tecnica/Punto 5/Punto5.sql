CREATE OR REPLACE PROCEDURE manipular_usuarios (
    p_opcion IN VARCHAR2 -- PARA SABER QUE QUEREMOS REALIZAR 
) IS
    v_promedio_edad NUMBER;
BEGIN
    IF p_opcion = 'DEVOLVER_TODOS' THEN
        -- Devolver todos los registros
        FOR rec IN (
            SELECT
                *
            FROM
                usuarios
        ) LOOP
            dbms_output.put_line('ID_USUARIO: '
                                 || rec.id_usuario
                                 || ', LOGIN: '
                                 || rec.login
                                 || ', CONTRASENA: '
                                 || rec.contrasena
                                 || ', ESTADO: '
                                 || rec.estado
                                 || ', FECHA_NACIMIENTO: '
                                 || rec.fecha_nacimiento);
        END LOOP;

    ELSIF p_opcion = 'PROMEDIO_EDAD' THEN
        -- Calcular el promedio de edad
        SELECT
            AVG(trunc(months_between(sysdate, fecha_nacimiento) / 12))
        INTO v_promedio_edad
        FROM
            usuarios
        WHERE
            fecha_nacimiento IS NOT NULL;

        dbms_output.put_line('Promedio de Edad: ' || v_promedio_edad);
    ELSIF p_opcion = 'ELIMINAR_TODOS' THEN
        -- Eliminar todos los registros
        DELETE FROM usuarios;

        dbms_output.put_line('Todos los registros han sido eliminados.');
    ELSE
        dbms_output.put_line('Opci�n no v�lida. Use DEVOLVER_TODOS, PROMEDIO_EDAD o ELIMINAR_TODOS.');
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        dbms_output.put_line('Error: ' || sqlerrm);
END;
/